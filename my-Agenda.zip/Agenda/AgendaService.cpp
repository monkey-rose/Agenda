#include"AgendaService.hpp"
#include<iostream>
using namespace std;
    /**
     * constructor
     */
    AgendaService::AgendaService() {
        m_storage = Storage::getInstance();
    }

    /**
     * destructor
     */
    AgendaService::~AgendaService() {
        m_storage->Storage::sync();
    }

    /**
     * check if the username match password
     * @param userName the username want to login
     * @param password the password user enter
     * @return if success, true will be returned
     */
    bool AgendaService::userLogIn(const std::string userName, const std::string password) {
        list<User> temp = m_storage->Storage::queryUser([userName, password](const User& user)->bool {
            if (userName == user.getName() && password==user.getPassword()) {
                return true;
            } else {
                return false;
            }
        });
        if (temp.empty()) return false;  
    return true;
}
    /**
     * regist a user
     * @param userName new user's username
     * @param password new user's password
     * @param email new user's email
     * @param phone new user's phone
     * @return if success, true will be returned
     */
    bool AgendaService::userRegister(const std::string userName, const std::string password,
                      const std::string email, const std::string phone) {
        list<User> temp = m_storage->Storage::queryUser([userName](const User& user)->bool {
            if (userName == user.getName()) {
                return true;
            } else {
                return false;
            }
        });
        if (temp.empty()) {
            User u(userName, password, email, phone);
            m_storage->createUser(u);
            return true;
        }
        return false;
    }

    /**
     * delete a user
     * @param userName user's username
     * @param password user's password
     * @return if success, true will be returned
     */
    bool AgendaService::deleteUser(const std::string userName, const std::string password) {
        int temp = m_storage->Storage::deleteUser([userName, password](const User& user)->bool {
            if (user.getName() == userName && user.getPassword() == password) {
                return true;
            } else {
                return false;
            }
        });
        if (temp == 0) return false;
        deleteAllMeetings(userName);
        m_storage->Storage::deleteMeeting([userName](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator();
            for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                if (*iter == userName) return true;
            }
            return false;
        });
        return true;
    }

    /**
     * list all users from storage
     * @return a user list result
     */
    std::list<User> AgendaService::listAllUsers(void) const {
        list<User> temp = m_storage->Storage::queryUser([](const User& user)->bool {
            return true;
        });
        return temp;
    }

    /**
     * create a meeting
     * @param userName the sponsor's userName
     * @param title the meeting's title
     * @param participator the meeting's participator
     * @param startData the meeting's start date
     * @param endData the meeting's end date
     * @return if success, true will be returned
     */
    bool AgendaService::createMeeting(const std::string userName, const std::string title,
                       const std::string startDate, const std::string endDate,
                       const std::vector<std::string> participator) {
        if (participator.empty()) return false;
        for (auto ite = participator.begin(); ite < participator.end(); ite++) {
            if (*ite == userName) return false;
        }
        Date a1 = Date::stringToDate(startDate);
        Date a2 = Date::stringToDate(endDate);
        if (!Date::isValid(a1)) return false;
        if (!Date::isValid(a2)) return false;
        if (a1 >= a2) return false;
        list<User> temp = m_storage->Storage::queryUser([userName](const User& user)->bool {
            if(userName == user.getName()) return true;
            return false;
        });
        if (temp.empty()) return false;
            list<User> tem = m_storage->Storage::queryUser([participator](const User& user)->bool {
                for (auto iter = participator.begin(); iter != participator.end(); iter++) {
            if(*iter == user.getName()) return true;
        }
        return false;
        });
        if (tem.size() != participator.size()) return false;
        std::list<Meeting> p = m_storage->Storage::queryMeeting([userName, a1, a2](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator();
            if ((a1 >= meeting.getStartDate() && a1 < meeting.getEndDate()) ||
                (a2 > meeting.getStartDate() && a2 <= meeting.getEndDate()) ||
                (a1 <= meeting.getStartDate() && a2 >= meeting.getEndDate())) {
                if (userName == meeting.getSponsor()) return true;
                for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                    if (*iter == userName) return true;
                }
                return false;
            }
            return false;
        });
        if (!p.empty()) return false;
        list<Meeting> q;
            q = m_storage->Storage::queryMeeting([participator, a1, a2](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator();
            for (auto it = participator.begin(); it != participator.end(); it++) {
            if ((a1 >= meeting.getStartDate() && a1 < meeting.getEndDate()) ||
                (a2 > meeting.getStartDate() && a2 <= meeting.getEndDate()) ||
                (a1 <= meeting.getStartDate() && a2 >= meeting.getEndDate())) {
                if (*it == meeting.getSponsor()) return true;
                for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                    if (*iter == *it) return true;
                }
            }
        }
        return false;
        });
        if (!q.empty()) return false;
        list<User> ha;
        ha = m_storage->Storage::queryUser([userName](const User& user)->bool {
            if (userName == user.getName()) {
                return true;
            } else {
                return false;
            }
        });
        if (ha.size() == 0) return false;
        list<User> haha;
        haha = m_storage->Storage::queryUser([participator](const User& user)->bool {
            for (auto cu = participator.begin(); cu != participator.end(); cu++) {
                if (*cu == user.getName()) {
                    return true;
                }
            }
            return false;
        });
        if (haha.size() != participator.size()) return false;
        list<Meeting> hahaha = m_storage->Storage::queryMeeting([title](const Meeting& meeting)->bool {
            if (title == meeting.getTitle()) {
                return true;
            } else {
                return false;
            }
        });
        if (!hahaha.empty()) return false;
        Meeting r(userName, participator, a1, a2, title);
        m_storage->Storage::createMeeting(r);
        return true;
    }

    /**
     * search meetings by username and title (user as sponsor or participator)
     * @param uesrName the user's userName
     * @param title the meeting's title
     * @return a meeting list result
     */
    std::list<Meeting> AgendaService::meetingQuery(const std::string userName,
                                    const std::string title) const {
        list<Meeting> temp = m_storage->Storage::queryMeeting([userName, title](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator();
            if (title == meeting.getTitle()) {
                if (userName == meeting.getSponsor()) return true;
                for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                    if (*iter == userName) return true;
                }
            }
            return false;
        });
        return temp;
    }
    /**
     * search a meeting by username, time interval (user as sponsor or participator)
     * @param uesrName the user's userName
     * @param startDate time interval's start date
     * @param endDate time interval's end date
     * @return a meeting list result
     */
    std::list<Meeting> AgendaService::meetingQuery(const std::string userName,
                                    const std::string startDate,
                                    const std::string endDate) const {
        Date a1 = Date::stringToDate(startDate);
        Date a2 = Date::stringToDate(endDate);
        list<Meeting> tak;
        if (!Date::isValid(a1)) return tak;
        if (!Date::isValid(a2)) return tak;
        if (a1 > a2) return tak;
        list<Meeting> temp = m_storage->Storage::queryMeeting([userName, a1, a2](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator();
            if ((a1 >= meeting.getStartDate() && a1 <= meeting.getEndDate()) ||
                (a2 >= meeting.getStartDate() && a2 <= meeting.getEndDate()) ||
                (a1 <= meeting.getStartDate() && a2 >= meeting.getEndDate())) {
                if (userName == meeting.getSponsor()) return true;
                for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                    if (*iter == userName) return true;
                }
                return false;
            }
            return false;
        });
        return temp;
    }

    /**
     * list all meetings the user take part in
     * @param userName user's username
     * @return a meeting list result
     */
    std::list<Meeting> AgendaService::listAllMeetings(const std::string userName) const {
        list<Meeting> temp = m_storage->Storage::queryMeeting([userName](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator(); 
            if (meeting.getSponsor() == userName) return true;
            for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                if (*iter == userName) return true;
            }
            return false;
        });
        return temp;
    }

    /**
     * list all meetings the user sponsor
     * @param userName user's username
     * @return a meeting list result
     */
    std::list<Meeting> AgendaService::listAllSponsorMeetings(const std::string userName) const {
        list<Meeting> temp = m_storage->Storage::queryMeeting([userName](const Meeting& meeting)->bool {
            if (meeting.getSponsor() == userName) return true;
            return false;
        });
        return temp;
    }

    /**
     * list all meetings the user take part in and sponsor by other
     * @param userName user's username
     * @return a meeting list result
     */
    std::list<Meeting> AgendaService::listAllParticipateMeetings(const std::string userName) const {
        list<Meeting> temp = m_storage->Storage::queryMeeting([userName](const Meeting& meeting)->bool {
            vector<string> mine = meeting.getParticipator();
            for (auto iter = mine.begin(); iter != mine.end(); iter++) {
                if (*iter == userName) return true;
            }
            return false;
        });
        return temp;
    }

    /**
     * delete a meeting by title and its sponsor
     * @param userName sponsor's username
     * @param title meeting's title
     * @return if success, true will be returned
     */
    bool AgendaService::deleteMeeting(const std::string userName, const std::string title) {
        int temp = m_storage->Storage::deleteMeeting([userName, title](const Meeting& meeting)->bool {
            if (meeting.getSponsor() == userName && meeting.getTitle() == title) return true;
            return false;
        });
        if (temp == 0) return false;
        return true;
    }

    /**
     * delete all meetings by sponsor
     * @param userName sponsor's username
     * @return if success, true will be returned
     */
    bool AgendaService::deleteAllMeetings(const std::string userName) {
        int temp = m_storage->Storage::deleteMeeting([userName](const Meeting& meeting)->bool {
            if (meeting.getSponsor() == userName) return true;
            return false;
        });
        if (temp == 0) return false;
        return true;
    }

    /**
     * start Agenda service and connect to storage
     */
    void AgendaService::startAgenda(void) {
        m_storage = Storage::getInstance();
    }

    /**
     * quit Agenda service
     */
    void AgendaService::quitAgenda(void) {
        m_storage->Storage::sync();
    }

