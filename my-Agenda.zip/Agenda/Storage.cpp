#include<iostream>
#include<fstream>
#include<string>
#include<memory>
#include"Storage.hpp"
#include"Path.hpp"
using namespace std;
std::shared_ptr<Storage> Storage::m_instance = NULL;
Storage::Storage() {
  readFromFile();
}
bool Storage::readFromFile(void) {
ifstream infile;
int len, i, t, n;
string temp, part = "";
User user;
infile.open(Path::userPath);
while (getline(infile, temp)) {
    len = temp.length();
        for (i = 1; i < len; i++) {
            if (temp[i] == '"') break;
        }
        for (t = 1; t < i; t++) {
            part += temp[t];
        }
        user.setName(part);
        part = "";
        for (t = i+3; t < len; t++) {
        	if (temp[t] == '"') break;
        }
        for (n = i+3; n < t; n++) {
        	part += temp[n];
        }
        user.setPassword(part);
        part = "";
        for (i = t+3; i < len; i++) {
        	if (temp[i] == '"') break;
        }
        for (n = t+3; n < i; n++) {
        	part += temp[n];
        }
        user.setEmail(part);
        part = "";
        for (t = i+3; t < len; t++) {
        	if (temp[t] == '"') break;
        }
        for (n = i+3; n < t; n++) {
        	part+= temp[n];
        }
        user.setPhone(part);
        part = "";
        m_userList.push_back(user);
}
infile.close();
infile.open(Path::meetingPath);
Meeting meeting;
string vec;
while (getline(infile, temp)) {
	len = temp.length();
        for (i = 1; i < len; i++) {
            if (temp[i] == '"') break;
        }
        for (t = 1; t < i; t++) {
            part += temp[t];
        }
        meeting.setSponsor(part);
        part = "";
        for (t = i+3; t < len; t++) {
        	if (temp[t] == '"') break;
        }
        for (n = i+3; n < t; n++) {
        	part += temp[n];
        }
        vec = part;
        part = "";
        for (i = t+3; i < len; i++) {
        	if (temp[i] == '"') break;
        }
        for (n = t+3; n < i; n++) {
        	part += temp[n];
        }
        meeting.setStartDate(Date::stringToDate(part));
        part = "";
        for (t = i+3; t < len; t++) {
        	if (temp[t] == '"') break;
        }
        for (n = i+3; n < t; n++) {
        	part += temp[n];
        }
        meeting.setEndDate(Date::stringToDate(part));
        part = "";
        for (i = t+3; i < len; i++) {
        	if (temp[i] == '"') break;
        }
        for (n = t+3; n < i; n++) {
        	part += temp[n];
        }
        meeting.setTitle(part);
        part = "";
        vector<string> mine;
        for (i = 0; i < vec.length(); i++) {
          if (vec[i] == '&') {
            mine.push_back(part);
            part = "";
          } else {
            part += vec[i];
          }
        }
        mine.push_back(part);
            part = "";
        meeting.setParticipator(mine);
        m_meetingList.push_back(meeting);
}
infile.close();
return true;
}

  /**
  *   write file content from memory
  *   @return if success, true will be returned
  */
  bool Storage::writeToFile(void) {
ofstream outfile;
outfile.open(Path::userPath);
for (auto iter = m_userList.begin(); iter != m_userList.end(); iter++) {
    outfile << '"' << iter->getName() << '"' << ',' << '"' << iter->getPassword() << '"' << ',' <<
    '"' << iter->getEmail() << '"' << ',' << '"' << iter->getPhone() << '"' << endl;
}
outfile.close();
outfile.open(Path::meetingPath);
string a1, a2;
for (auto iter = m_meetingList.begin(); iter != m_meetingList.end(); iter++) {
    outfile << '"' << iter->getSponsor() << '"' << ',' << '"';
    for (int i = 0; i < iter->getParticipator().size()-1; i++) {
    	outfile << iter->getParticipator().at(i) << '&';
    }
    outfile << iter->getParticipator().at(iter->getParticipator().size()-1) << '"' << ',';
    a1 = Date::dateToString(iter->getStartDate());
    a2 = Date::dateToString(iter->getEndDate());
    outfile << '"' << a1 << '"' << ',' << '"' << a2 << '"' << ',' << '"' << iter->getTitle() << '"' << endl;
}
outfile.close();
return true;
  }

 shared_ptr<Storage> Storage::getInstance(void) {
    if (m_instance == nullptr) {
      m_instance.reset(new Storage());
    }
      return m_instance;
  }

  /**
  *   destructor
  */
  Storage::~Storage() {
  	writeToFile();
  }

  // CRUD for User & Meeting
  // using C++11 Function Template and Lambda Expressions

  /**
  * create a user
  * @param a user object
  */
  void Storage::createUser(const User & t_user) {
  	m_userList.push_back(t_user);
  }

  /**
  * query users
  * @param a lambda function as the filter
  * @return a list of fitted users
  */
  std::list<User> Storage::queryUser(std::function<bool(const User &)> filter) const {
  	list<User> temp;
  	for (auto iter = m_userList.begin(); iter != m_userList.end(); iter++) {
  		if (filter(*iter)) temp.push_back(*iter);
  	}
  	return temp;
  }

  /**
  * update users
  * @param a lambda function as the filter
  * @param a lambda function as the method to update the user
  * @return the number of updated users
  */
  int Storage::updateUser(std::function<bool(const User &)> filter,
                 std::function<void(User &)> switcher) {
  	int number = 0;
  	for (auto iter = m_userList.begin(); iter != m_userList.end(); iter++) {
  		if (filter(*iter)) {
  			switcher(*iter);
  			number++;
  		}
  	}
  	m_dirty = 1;
  	return number;
  }

  /**
  * delete users
  * @param a lambda function as the filter
  * @return the number of deleted users
  */
  int Storage::deleteUser(std::function<bool(const User &)> filter) {
    int number = 0;
    for (auto iter = m_userList.begin(); iter != m_userList.end();) {
    	if (filter(*iter)) {
    		auto it = iter;
        iter++;
    		m_userList.erase(it);
    		number++;
    	} else {
        iter++;
      }
    }
    return number;
  }

  /**
  * create a meeting
  * @param a meeting object
  */
  void Storage::createMeeting(const Meeting & t_meeting) {
  	m_meetingList.push_back(t_meeting);
  }

  /**
  * query meetings
  * @param a lambda function as the filter
  * @return a list of fitted meetings
  */
  std::list<Meeting> Storage::queryMeeting(std::function<bool(const Meeting &)> filter) const {
  	list<Meeting> temp;
  	for (auto iter = m_meetingList.begin(); iter != m_meetingList.end(); iter++) {
  		if (filter(*iter)) temp.push_back(*iter);
  	}
  	return temp;
  }

  /**
  * update meetings
  * @param a lambda function as the filter
  * @param a lambda function as the method to update the meeting
  * @return the number of updated meetings
  */
  int Storage::updateMeeting(std::function<bool(const Meeting &)> filter,
                    std::function<void(Meeting &)> switcher) {
  	int number = 0;
  	for (auto iter = m_meetingList.begin(); iter != m_meetingList.end(); iter++) {
  		if (filter(*iter)) {
  			switcher(*iter);
  			number++;
  		}
  	}
  	m_dirty = 1;
  	return number;
  }

  /**
  * delete meetings
  * @param a lambda function as the filter
  * @return the number of deleted meetings
  */
  int Storage::deleteMeeting(std::function<bool(const Meeting &)> filter) {
  	int number = 0;
    for (auto iter = m_meetingList.begin(); iter != m_meetingList.end();) {
    	if (filter(*iter)) {
    		auto it = iter;
    		iter++;
    		m_meetingList.erase(it);
    		number++;
    	} else {
    		iter++;
    	}
    }
    return number;
  }

  /**
  * sync with the file
  */
  bool Storage::sync(void) {
  		writeToFile();
  }
