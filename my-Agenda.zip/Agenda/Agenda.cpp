#include "AgendaUI.hpp"

AgendaUI aui;

int main() {
    aui.OperationLoop();
    return 0;
}
